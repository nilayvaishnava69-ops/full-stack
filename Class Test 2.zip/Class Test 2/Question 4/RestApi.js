const express = require("express");

const app = express();
app.use(express.json());

let books = [
  { id: 1, title: "Book One", author: "Author A" },
  { id: 2, title: "Book Two", author: "Author B" }
];

// GET all books
app.get("/api/books", (req, res) => {
  res.json(books);
});

// POST new book
app.post("/api/books", (req, res) => {
  const book = {
    id: books.length + 1,
    title: req.body.title,
    author: req.body.author
  };

  books.push(book);
  res.status(201).json(book);
});

// DELETE book
app.delete("/api/books/:id", (req, res) => {
  const id = Number(req.params.id);
  const index = books.findIndex(b => b.id === id);

  if (index === -1)
    return res.status(404).json({ error: "Book not found" });

  books.splice(index, 1);
  res.json({ message: "Book deleted" });
});

app.listen(5000);