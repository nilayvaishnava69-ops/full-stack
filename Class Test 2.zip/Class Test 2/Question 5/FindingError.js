// If the ID doesn't exist, book is undefined, so:

// book.title

// causes an error.

//corrected code

app.get("/api/books/:id", (req, res) => {
  const book = books.find(b => b.id == req.params.id);

  if (!book) {
    return res.status(404).json({ error: "Book not found" });
  }

  res.json(book.title);
});