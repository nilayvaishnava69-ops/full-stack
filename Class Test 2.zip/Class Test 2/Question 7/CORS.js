// The browser blocks requests between different origins (localhost:3000 and localhost:5000) unless the API allows that origin. Postman doesn't enforce browser CORS rules.

const cors = require("cors");

app.use(cors({
  origin: "http://localhost:3000"
}));