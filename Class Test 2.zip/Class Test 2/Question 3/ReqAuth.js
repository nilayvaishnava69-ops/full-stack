const express = require("express");

const app = express();
app.use(express.json());

function requireAuth(req, res, next) {
  if (req.headers["x-api-key"] !== "secret123") {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

app.get("/api/books", (req, res) => {
  res.json([]);
});

app.post("/api/books", requireAuth, (req, res) => {
  res.status(201).json(req.body);
});

app.listen(5000, () => console.log("Server running"));