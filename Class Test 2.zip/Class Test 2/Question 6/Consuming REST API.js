import { useEffect, useState } from "react";

export default function BookList() {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("http://localhost:5000/api/books")
      .then(res => {
        if (!res.ok) throw new Error("Failed to fetch books");
        return res.json();
      })
      .then(data => setBooks(data))
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <ul>
      {books.map(book => (
        <li key={book.id}>
          {book.title} - {book.author}
        </li>
      ))}
    </ul>
  );
}