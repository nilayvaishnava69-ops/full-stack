import { useState } from "react";

export default function LoginToggle() {
  const [login, setLogin] = useState(false);

  return login ? (
    <>
      <h2>Welcome!</h2>
      <button onClick={() => setLogin(false)}>Logout</button>
    </>
  ) : (
    <button onClick={() => setLogin(true)}>Login</button>
  );
}
