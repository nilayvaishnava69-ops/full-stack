import { useState, useRef } from "react";

export default function Stopwatch() {
  const [time, setTime] = useState(0);
  const timer = useRef(null);

  const start = () => {
    if (!timer.current)
      timer.current = setInterval(() => setTime(t => t + 1), 1000);
  };

  const pause = () => {
    clearInterval(timer.current);
    timer.current = null;
  };

  const reset = () => {
    pause();
    setTime(0);
  };

  return (
    <>
      <h2>{time} seconds</h2>
      <button onClick={start}>Start</button>
      <button onClick={pause}>Pause</button>
      <button onClick={reset}>Reset</button>
    </>
  );
}
