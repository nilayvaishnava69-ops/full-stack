import { useState } from "react";

export default function LiveSearch() {
  const [search, setSearch] = useState("");

  const names = [
    "Rahul", "Aman", "Priya", "Neha",
    "Rohit", "Ankit", "Sneha", "Vishavjeet"
  ];

  const result = names.filter(n =>
    n.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <>
      <input
        placeholder="Search"
        value={search}
        onChange={e => setSearch(e.target.value)}
      />

      {result.length ? (
        <ul>{result.map((n, i) => <li key={i}>{n}</li>)}</ul>
      ) : (
        <p>No results found</p>
      )}
    </>
  );
}
