import { useState } from "react";

export default function Counter() {
  const [count, setCount] = useState(0); 

  return (
    <>
      <h2>{count}</h2>
      <button onClick={() => setCount(count + 1)}>Increment</button>
      <button disabled={count === 0} onClick={() => setCount(count - 1)}>
        Decrement
      </button>
      <button onClick={() => setCount(0)}>Reset</button>
    </>
  );
}

